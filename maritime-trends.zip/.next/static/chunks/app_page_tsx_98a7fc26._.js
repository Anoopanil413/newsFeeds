(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_93c5524f._.js",
  "static/chunks/_d6d7731a._.js"
],
    source: "dynamic"
});
