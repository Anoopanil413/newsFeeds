import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Bot, MousePointer, Globe } from "lucide-react"

export default function ServicesSection() {
  const features = [
    {
      icon: Bot,
      iconBg: "bg-blue-600",
      title: "Smart Curation",
      description:
        "AI analyzes maritime relevance, crew nationality preferences, and vessel type to deliver personalized content.",
      features: ["Politics & Trade Policy", "Weather & Route Planning", "Safety Regulations", "Technology Updates"],
    },
    {
      icon: MousePointer,
      iconBg: "bg-orange-700",
      title: "Bandwidth Optimized",
      description:
        "Compressed to under 50KB per email with essential images and safety posters optimized for satellite connections.",
      features: ["90% size reduction", "Text-optimized format", "Critical images only", "Offline reading ready"],
    },
    {
      icon: Globe,
      iconBg: "bg-green-600",
      title: "Global Reach",
      description:
        "Content tailored for Indian, Filipino, Ukrainian, and Chinese crew with region-specific maritime news and safety updates.",
      features: ["Multi-language summaries", "Regional regulations", "Cultural considerations", "Local port updates"],
    },
  ]

  return (
    <section className="py-24 bg-slate-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-4xl lg:text-5xl font-bold text-white mb-8">AI-Powered Maritime Intelligence</h2>
          <p className="text-lg text-gray-400 max-w-4xl mx-auto leading-relaxed">
            Our advanced AI scans thousands of maritime sources daily, compressing essential news into bite-sized
            updates perfect for shipboard connectivity.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          {features.map((feature, index) => (
            <Card
              key={index}
              className="bg-slate-800/60 border-slate-700/50 hover:scale-105 transition-all duration-300 ease-out hover:bg-slate-800/80 hover:border-slate-600/60"
            >
              <CardContent className="p-8">
                <div className={`w-14 h-14 ${feature.iconBg} rounded-xl flex items-center justify-center mb-8`}>
                  <feature.icon className="h-7 w-7 text-white" />
                </div>

                <h3 className="text-2xl font-bold text-white mb-6">{feature.title}</h3>

                <p className="text-gray-400 mb-8 leading-relaxed text-base">{feature.description}</p>

                <ul className="space-y-3">
                  {feature.features.map((item, itemIndex) => (
                    <li key={itemIndex} className="flex items-start text-gray-400 text-sm">
                      <div className="w-1.5 h-1.5 bg-gray-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Button className="bg-blue-600 hover:bg-blue-700 text-white px-10 py-4 text-base font-semibold rounded-lg">
            See Sample Newsletter
          </Button>
        </div>
      </div>

      {/* Activate Windows watermark */}
      <div className="absolute bottom-6 right-6 text-right">
        <p className="text-gray-500 text-base font-medium">Activate Windows</p>
        <p className="text-gray-600 text-sm">Go to Settings to activate Windows.</p>
      </div>
    </section>
  )
}
